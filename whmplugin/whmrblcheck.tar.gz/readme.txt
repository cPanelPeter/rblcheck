rblcheck - a simple plugin created specifically for a walkthrough on how to create a Plugin
for WHM. 

Allows you to check your servers main IP and any ipaliases against a list of RBL's 
(Realtime Blackhole Lists).  

INSTALLATION: 

Download the rblcheck_install.pl script to /root and run it (as root).  
Once completed, you should have an rblcheck plugin under WHM => Plugins.


